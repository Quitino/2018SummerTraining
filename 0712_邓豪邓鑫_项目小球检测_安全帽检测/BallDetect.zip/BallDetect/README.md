# Introduction
本工程是2017年全国电子设计大赛中的滚球控制系统（B题）的图像处理解决方案。
该工程支持Windows、Linux平台。

# License
无

# Dependencies
* OpenCV 
* CMake (>=2.6)

# Building

通过CMake编译工具编译

# Note for Linux users

可以在解压后直接运行build.sh文件自动完成

# Object Selection
按下键“S”或“Enter”开始处理，按下键“Q”或“ESC”退出



